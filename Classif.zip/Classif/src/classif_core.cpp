  #include <Rcpp.h>
  #include <iostream>
  #include <ostream>
  #include <math.h>
  
  
  #include <sstream>
  #include <fstream>
  #include <string>
  
  #include <cstring>
  #include <math.h>
  #include <R.h>
  #include <Rinternals.h>
  
  
  
  // list::sort
  #include <vector>
  #include <list>
  #include <cctype>
  
  #include <array> 
  
  
#include <gmp.h>                /* GNU GMP Library       */
  using namespace std;
  using namespace Rcpp;
  
  //template <typename T>
  //using TwoDdouble = vector<vector<T>>;
  
  
  
  typedef vector < vector< double > > TwoDdouble;
  typedef vector < vector< int > > TwoDint;
  
  typedef vector < vector<  int64_t > > TwoDlong;
  
  
    // function that compute the combinations number 
    int64_t nChoosek( int n, int k )
  {
    if (k > n) return 0;
    if (k * 2 > n) /*return*/ k = n-k;  //remove the commented section
    if (k == 0) return 1;
    
     int64_t result = n;
    for( int i = 2; i <= k; ++i ) {
      result *= (n-i+1);
      result /= i;
    }
    return result;
  }
  
  
  // [[Rcpp::export]]
  
  List fun(NumericMatrix pred1,NumericVector implifvarsord,int nvotes,bool verbose) {
  
      clock_t t1, t2;
      long clk_tck = CLOCKS_PER_SEC;
  
      List results(4);
  
      CharacterVector names_implif = implifvarsord.names();
  
      List names_pred2=pred1.attr("dimnames");
      List pred1_names=names_pred2[1];
      for(int g=0;g<(pred1_names.size());g++){
        string val=pred1_names[g];
      }
  
      TwoDdouble pred2(pred1.nrow(),vector<double> (pred1.ncol()));
  
      for(int i=0;i<(pred1.nrow());i++)
        for(int j=0;j<(pred1.ncol());j++) {
          pred2[i][j]=pred1(i,j);
        }
  
        int n = implifvarsord.size();
  
       int64_t som=0;
      // compute the combinations number
  
      for(int jj = 1; jj<=nvotes; jj++) {
  
        som=som+nChoosek(n,jj);
  
        jj=jj+1;}
      
      
      
      vector<string>   predname(som);
  
      double minimplif[som];
  
      // Vecteur contenant la prediction correspendant a chaque combinaison
      vector< int64_t>   veck(som);
      int q=0;
      int tail=pred1.nrow();
  
      TwoDlong predComb(tail,vector< int64_t> (som));
  
      for(int i=0;i<tail;i++)
        for(int j=0;j<som;j++) predComb[i][j]=0;
  
      //calcule de la liste de combinaisons
  
      for(int jj = 1; jj<=nvotes; jj++) {
  

        t1 = clock();
        cout<<" Bulding the matrix of "<< jj<<"  classifyers..."<<endl;
        
   
        int k = jj;
         int64_t var1;
  
         int64_t nbComb = nChoosek(n,k);
         
         int64_t t=nbComb*jj;


         int64_t comb[t] = {0};
        char comb1[t];
  
        vector<string>   tabcomb(jj);
  
        double tabcombimplif[jj];
        int i = 0;
        int p=0;
        int m;
        // compute the combinations
        while (i >= 0) {

          if (comb[i] < n + i - k + 1) { comb[i]++;

            if (i == k - 1) {
              m=0;
              for (int j = 0; j < k; j++)
              {
                var1=comb[j]-1;
                tabcomb[m]=names_implif[var1];
                tabcombimplif[m]=implifvarsord[var1];
                m=m+1;
              }
              
              string var=tabcomb[0];

              //compute the prediction for each combination
  
              double min=tabcombimplif[0];
              for (int s = 1; s < jj; s++){
                var=var+"+"+tabcomb[s];

                if(min>tabcombimplif[s])
                { min=tabcombimplif[s];}
              }

              predname[q]=var;
              minimplif[q]=min ;
              veck[q]=jj;
  
              if(k==1){
                for (int s1 = 0; s1 < pred1.nrow(); s1++){
                  //extract the num of var in the list name
                  int index;
                  for (int g = 0; g < pred1_names.size(); g++){
                    string val=pred1_names[g];
                    if(val==var){
                      index=g;
                      break;
                    }
                  }
                  predComb[s1][q]=pred2[s1][index];
                  //cout<<"predComb[s1][q]"<< predComb[s1][q]<<endl; 
                }
              }
              else{
                for (int s1 = 0; s1 < pred1.nrow(); s1++){
                  int nbrpos=0;
                  int nbrneg=0;
  
                  //compute the majority prediction
                  vector<int> tabtemp(jj);
  
                  for (int s2 = 0; s2 < jj; s2++){
                    string r=tabcomb[s2];
                    int index;
                    for (int g = 0; g < pred1_names.size(); g++){
                      string val=pred1_names[g];
                      if(val==r){
                        tabtemp[s2]=g;
                        break;
                      }
                    }
  
                  }
                  for (int s2 = 0; s2 < jj; s2++){
  
                    int index=tabtemp[s2];
                    if(pred2[s1][index]==1)
                    {nbrpos=nbrpos+1;}
                    else
                    {nbrneg=nbrneg+1;}
  
                  }
                  if(nbrpos>nbrneg)
                  { predComb[s1][q]=1; } 
                  else{ predComb[s1][q]=0; }
                }
              }
    
  
              p=p+1;
              q=q+1;
  
            } else { i=i+1;comb[i] = comb[i - 1]; 

              }
          } else i--;

  
        }
  
        jj=jj+1;
  
        t2 = clock();
  
        (void)printf("Temps consomme (s) : %lf \n",
         (double)(t2-t1)/(double)clk_tck);
      }
  
      vector<double>   vecm(som);
  
      for(int j=0;j<som;j++){
  
        vecm[j]=minimplif[j];
      }
  
  
      results[0]=predname;
      results[1]=vecm;
      results[2]=veck;
      results[3]=predComb;
  
  
      return(results);
    
    
    }
  
