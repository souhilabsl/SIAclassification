#' @title MAKE THE CLASSIFICATION WITH SIA
#'
#' @description 
#'
#' @param   formula        
#' @param   data  
#' @param   implif0  
#' @param   positive       
#' @param   optim    
#' @param   nvotes      
#' @param   verbose         
#'
#' @author 

#' @export


SIAclassif = function(formula=NULL, data, implif0=0.1, positive=NULL,
                      optim='accuracy', nvotes=3,  verbose=TRUE) {
  # formula ok
  # data ok
  # inplif0: implifidence threshold
  # positive: "name" of the positive class
  # optim: what to optimize? acc, pre, sen, spe or a combination of all
  # nvotes: number of voting group for classification
  stopifnot(!is.null(formula))
  stopifnot(is.element(optim,
                       c('accuracy', 'precision', 'sensitivity', 'specificity')))
  # main body
  #formula = formula(as.character(formula))
  inputvars <<- attr(terms(formula,data=data), "term.labels")
  
  input = data[,inputvars]
  
  class = factor(data[,all.vars(formula)[1]])


  # compute all classifying 2-length rules
  
  # all columns should be factors
  for(v in inputvars) {
    input[,v] = factor(input[,v])
  }
  
  require(arules)
  x2 <<- cbind(input, class=class)
  
  # a simple function needed for voting
  majority = function(x) {
    return(names(table(x))[which.max(table(x))])
  }
  # a simple function needed for replace class name with 1 or 0
  remplace = function(x) {
    if(setequal(x,positive)==TRUE)
    {x=1}else{x=0}}
   remplace1 = function(x) {
     if(x==1){x=positive}else{ x=neg}   }
      
 # another function for adding implifidence to a set of rules
  # check interestMeasure() since it contains more measures
  # and taking some of them would help to compute implifidence
  # without the transaction data
  add.implif = function(trans, rules) {
  ruletext = data.frame(lhs=lhs(rules)@itemInfo$labels[1+lhs(rules)@data@i],
                          rhs=rhs(rules)@itemInfo$labels[1+rhs(rules)@data@i])
  nr = dim(ruletext)[1]
  counts2 = matrix(0, nrow=nr, ncol=4)
  for(i in 1:nr) {
      freqs = table(as.data.frame(as(trans, 'matrix')[,c(as.character(ruletext[i,1]),
                                                         as.character(ruletext[i,2]))]))
      counts2[i,] = c(freqs[1,1], freqs[1,2], freqs[2,1], freqs[2,2])
    }
    n = dim(trans)[1]
    nab = counts2[,4]
    na = counts2[,3] + counts2[,4]
    nb = counts2[,2] + counts2[,4]
    nnota = counts2[,1] + counts2[,2]
    nnotb = counts2[,1] + counts2[,3]
    nanotb = counts2[,3]
    nnotab = counts2[,2]
    nnotanotb = counts2[,1]
    # confidence
    conf = nab/na
    # confidence of inverse rule (not b implies not a)
    conf2 = nnotanotb/nnotb
    # phi under Poisson model
    phi = 1 - ppois(nanotb, na*nnotb/n)
    # implifidence
    impl = phi*(conf*conf2)^0.25
    # now append phi and implifidence to rules
    rules@quality = cbind(rules@quality, phi=phi, impl=impl)
    return(rules)
  }
  # store all rules rijm, {input_i=value_i_j} -> {class=m}
  if(verbose==TRUE) { t0=as.numeric(proc.time()['elapsed']); cat("\nComputing rules with apriori...") }
  rijm <<- list()
  for(v in inputvars) { # for every input variable
    # create the transactions of input variable and class
    xij = as( x2[, c(v, 'class')], 'transactions')
 
    # extract all the rules implying the classes
    rijm[[v]] <<- arules::subset(apriori(xij, parameter=list(minlen=2, maxlen=2, conf=0, support=0),
                                         control=list(verbose=FALSE)), subset=(!(lhs %pin% "class=") & (rhs %pin% "class=")))
    
    # add the implifidences
    rijm[[v]] <<- add.implif(trans=xij, rules=rijm[[v]])
    # for each level of the input factor, sort the two rules by implifidence
    # and discard the second rule (because it has smaller implifidence after ordering)
  
    rijm[[v]] <<- rijm[[v]][ order(lhs(rijm[[v]])@itemInfo$labels[1+lhs(rijm[[v]])@data@i], rijm[[v]]@quality$impl,rhs(rijm[[v]])@itemInfo$labels[1+rhs(rijm[[v]])@data@i]) ][c(FALSE, TRUE)]
  
        }
  
  if(verbose==TRUE) { t1=as.numeric(proc.time()['elapsed']); cat("[", t1-t0, "sec.]\n"); t0=t1 }
  # compute the implifidence for which the rule will be a "classifying rule"
  implifvars = numeric(length(inputvars))
  names(implifvars) = inputvars
  for(v in inputvars) {
    implifvars[v] = min(rijm[[v]]@quality$impl)
  }
  # restrict to variables that exceed the implifidence threshold 'implif0'
  
  
  inputvars <<- inputvars[implifvars >= implif0]
  implifvars = implifvars[inputvars]
  
  
  #j'ai rajouter ?a pour traiter le bug dans le cas ou le seuil d'implifiance est grand par rapport...
  ninputvars <<- length(inputvars)
  
 
  nvotes = min(ninputvars, nvotes)
  
  # makes predictions per input variable using the classifying rules
  if(verbose==TRUE) { t1=as.numeric(proc.time()['elapsed']); cat("Bulding the matrix of classifyers..."); t0=t1 }
  # start a data frame such as the input
  
  # s'il ya au moin une variable dont la valeur d'implifiance est > au seuil.. dans inputvars
  if(ninputvars>0)
  {
    pred = x2[, inputvars]
    
    #j'ai rajouter ?a car ya un bug dans le cas ou ya une seule variable dans inputvars 
    c=nrow(x2)
    pred = matrix("", nrow=c, ncol=ninputvars)
    colnames(pred) <- inputvars
    
    # start each column with the true classes (only to have the levels present)
    for(v in inputvars) {
      pred[, v] = x2[, 'class']
    }
    
    # this block associates the class to each factor of the input variable
    forpred = list()
    
    for(v in inputvars) {
    
      inn = gsub(pattern=paste(v,'=', sep=''),
                 replacement='', x=lhs(rijm[[v]])@itemInfo$labels[1+lhs(rijm[[v]])@data@i])
 
      out = gsub(pattern=paste('class=', sep=''),
                 replacement='', x=rhs(rijm[[v]])@itemInfo$labels[1+rhs(rijm[[v]])@data@i])
      names(out) = inn
      pred[,v] = out[x2[,v]]
      forpred[[v]] = out

      names(forpred[[v]]) = inn
    }
    if(verbose==TRUE) { t1=as.numeric(proc.time()['elapsed']); cat("[", t1-t0, "sec.]\n"); t0=t1 }
    # now sort variables per implifidence
    implifvarsord = sort(implifvars, decreasing=TRUE)
   
    #replace the class names by 1 or 0
     pos = positive
     categ = unique(x2$class)
     neg = as.character(categ[categ != pos])
    pred1 = apply(X=pred[,], MAR=c(1,2), FUN='remplace')
    
    #call the funComputation function that:
    # include the most important variables (by implifidence)
    # in groups of 1, 3, 5,...
    # compute the quality of classification,
    # choose the best combination for each size
    # and report everything as output
    # predictions for the first important variable
    # for the next ones, we shall combine all important variables and vote
    
    res=callfunComputation(pred1,implifvarsord,nvotes,verbose)



        predname=unlist(res[[1]][])
        siz=length(predname)

        vecm=unlist(res[[2]][])

        veck=unlist(res[[3]][])

        pred3 <- matrix(unlist(res[[4]]), ncol = siz, byrow = TRUE)
        colnames(pred3)=predname



        pred3 = apply(X=pred3[,], MAR=c(1,2),FUN='remplace1')

        pred3 = data.frame(pred3[,])



        qual = data.frame(matrix(0, ncol=6, nrow=dim(pred3)[2]))
        dimnames(qual) = list(names(pred3),
                              c('accuracy', 'precision', 'sensitivity', 'specificity', 'implif0', 'size'))


        for(i in 1:dim(pred3)[2]) {
          t = table(pred=pred3[,i], true=x2$class)
          tp = t[pos,pos]
          tn = t[neg,neg]
          fp = t[pos,neg]
          fn = t[neg,pos]

          qual[i,] =c((tp+tn)/sum(t), tp/(tp+fp), tp/(tp+fn), tn/(tn+fp), vecm[i], veck[i])
        }



         bestvars <<- character(0)
         for(k in unique(veck)) {
          bestcomb = row.names(qual[veck==k,])[qual[veck==k, optim] == max(qual[veck==k, optim])]
          num_best=k
          bestvars <<- c(bestvars, bestcomb)
          # bestcomb keeps all combinations attaining the maximum value
         }



        quality=qual[bestvars,]
         # write the rules for all group sizes
         finalrule = list()
         for(i in 1:dim(quality)[1]) {
          finalrule[[i]] = paste("Classify as '", positive, "' iff at least ", ceiling(quality$size[i]/2),
                                  " of the following variables hold: ", sep='')
           vars = strsplit(row.names(quality)[i], split='.', fixed=TRUE)[[1]]
           for(v in vars) {
             valuesforpositive = (lhs(rijm[[v]])@itemInfo$levels[1+lhs(rijm[[v]])@data@i])[rhs(rijm[[v]])@itemInfo$levels[1+rhs(rijm[[v]])@data@i] == positive]
             if(length(valuesforpositive)==0) finalrule[[i]] = c(finalrule[[i]], '') else {
               finalrule[[i]] = paste(finalrule[[i]], paste(v, '={', paste(valuesforpositive, collapse=','),
                                                           '}; ', sep=''), sep='')
           }
          }
          finalrule[[i]] = paste(finalrule[[i]], paste(". The '", optim, "' is ", quality[i, optim], ".", sep=''), sep='')
        }
        classifyingvars = strsplit(x=bestvars[which.max(quality[,optim])], split="\\.")
        fittedval = pred3[, bestcomb[1]] # in case of withdrawal, take the first one
        names(fittedval) = 1:length(fittedval)
        return(structure(list(maximize=optim, positiveclass=positive, quality=quality,implifidence=implifvarsord, rules=finalrule, data=data, inputvars<<-inputvars, bestvars<<-bestvars,classifyingvars=unlist(classifyingvars), forprediction=forpred, fitted.values=fittedval), class="SIAclassif")
        )

  }else #s'il n ya pas de variable dont l'implifiance est sup?rieur au seuil 
  {
    
    print("vous avez introduit une valeur d'implifiance grande par rapport a celle des variables")
  }
}