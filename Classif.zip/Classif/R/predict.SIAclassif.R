#' @title MAKE THE PREDICTION
#'
#' @description 
#'

#' @author 
#' @export
predict.SIAclassif = function(object=NULL, newdata=NULL) {
  
  
  if(is.null(newdata)) newdata=object$data
  
  stopifnot(class(object)=="SIAclassif")
  
  classifyingvars = object$classifyingvars
  forpredmatrix <<- object$forprediction
  
  rules <<- object$rules
  

  stopifnot(is.element(classifyingvars, names(newdata)))
  
  pred0 = matrix("", nrow=dim(newdata)[1], ncol=length(classifyingvars))
  
  dimnames(pred0) = list(row.names(newdata), classifyingvars)
  
# function to find the value closest to the value that give NA 
  
  Verif_Dicho = function(trv1, q, min, max) {
 
    actuel=((max+min) %/% 2)
    if( min == max )
      return (q)
    
    if (min +1 == max)
    {
      if ((q-trv1[min] <= trv1[max]-q))
        return (trv1[min])
      else
        return (trv1[max])
    }
    
    if( q > trv1[actuel] )
      return (Verif_Dicho(trv1,q, actuel, max))
    else
      return (Verif_Dicho(trv1,q, min, actuel))
  }

  
  for(v in classifyingvars) {
    
    pred0[,v] = as.character(forpredmatrix[[v]][ as.character(newdata[, v])])
    
    #index: le numero de ligne dans l'ensemble de test ts dont la prediction donne le NA
    index=which(is.na(as.character(forpredmatrix[[v]][ as.character(newdata[, v])])))

    if(length(index)!=0)
    {
      #ch?rcher une prediction pour les valeurs qui donne le NA
      forpredname=as.numeric(names(forpredmatrix[[v]]))
      
      forpredname1=sort(forpredname)

      min=1
      max=length(forpredname1)
      val= as.character(newdata[index, v])
      val=as.numeric(val)
      #si la valeur qui donne le NA est > max
     for(i in 1:length(val)) {
         if(val[i]>forpredname1[max]){
          index1=index[i]
          val2=forpredname1[max]
          pred0[index1,v]=forpredmatrix[[v]][[as.character(val2)]]
        }
        else{
          #si la valeur qui donne le NA est < min
          
          if(val[i]<forpredname1[min]){
            index2=index[i]
            val2=forpredname1[min]
            pred0[index2,v]=forpredmatrix[[v]][[as.character(val2)]]
          }
          #si la valeur qui donne est entre min et max
          
            else{#mettre la prediction de la valeur la plus proche

             val2=Verif_Dicho(forpredname1,val[i], min, max)
             
             index2=index[i]
             pred0[index2,v]=forpredmatrix[[v]][[as.character(val2)]]}}
         }}
    
  }
  
  # a simple function needed for voting
  majority = function(x) {
    return(names(table(x))[which.max(table(x))])
  }
  predfinal <<- apply(X=pred0, MAR=1, FUN='majority')
  
  
  return(predfinal)
}

