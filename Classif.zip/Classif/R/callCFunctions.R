#' @title Calls the C++ function thate combinations...
#'
#' @description 
#' 
#' @author 
#' @export
#' 
#' @importFrom Rcpp evalCpp
#'
#' @useDynLib Classif
# 



#' @title compute combination and make the prediction .
#'
#' @description 
#'
#' @param  
#' 
#' @author 
#' @export
#' @useDynLib Classif
#' 
 callfunComputation <- function(pred1,implifvarsord,nvotes,verbose)  {
.Call('_Classif_fun',pred1,implifvarsord,nvotes,verbose)

}

