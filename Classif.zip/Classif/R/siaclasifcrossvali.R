#' @title siaclasifcrossvali
#'
#' @description Reads the data, prepare the data, make the cross validation 
#' call to the algorithmes NB, SVM, CART, J48 and SIA_classif
#' @details 
#'make the classification

#'
#' @author 
#' @export
#' 
#' 
#' @title Call to the  THE CLASSIFICATION ALGORITHMES
#'
#' @description 
#'
#' @param   formula        
#' @param   data  
#' @param   implif0  
#' @param   positive       
#' @param   optim    
#' @param   nvotes      
#' @param   verbose         
#'
#' @author  

#' @export




siaclasifcrossvali <-function(fileName){

#setwd("C:/Users/350752/Desktop/Rchic23fevrier/Rchic2/Rchic-master/data")

require("RWeka") # for J48 and more
require("rpart") # for CART
require("e1071") # for SVM and naiveBayes
require("caret") # for confusionMatrix
require("classInt") # for confusionMatrix


#######################################


# read all datasets

datasets <- list(0)

#datasets[[1]] = read.table(file='wdbc.csv', header=TRUE, sep=',', colClasses='factor')
#datasets[[2]] = read.table(file='IDs_mapping(EEG Eye State Data Set).csv', header=TRUE, sep=',', colClasses='factor')
#datasets[[3]] = read.table(file='sobar-72mod.csv', header=TRUE, sep=',', colClasses='factor')
#datasets[[1]] = read.table(file='breast-cancer-wisconsin.csv', header=TRUE, sep=',', colClasses='factor')
#datasets[[5]] <- read.table(file='wpbc.csv', header=TRUE, sep=',', colClasses='factor')
#datasets[[6]] <- read.table(file='haberman.csv', header=TRUE, sep=',', colClasses='factor')
#names(datasets) = c('WDBC','IDs_mapping','SOBAR', 'WBC', 'WPBC', 'haberman')

datasets[[1]] = read.csv(fileName,sep=",", colClasses='factor')



#datasets[[1]] = read.table(file=fileName, header=TRUE, sep=',', colClasses='factor')

#names(datasets) = c('wbc')

names(datasets) = "name1"


#datanames= c('WDBC','IDs_mapping','SOBAR', 'WBC', 'WPBC', 'haberman')
#datanames= c('wbc')
datanames= "name"

# need to identify positive class for each dataset
#positive = c('M','pos','pos', 'malignant', 'R', 'D')
#positive = c('malignant')
positive = positif



# number of folds, 5, 10 or dim(dataset)[1]
k = 5
# for keeping all 4 results for each method and fold
quality = array(0, dim=c(1,4,5,k),
                dimnames=list(dataset=datanames,
                              measure=c("acc", "pre", "sen", "spe"),
                              method=c("NB", "CART","J48", "RadSVM","SIA"),
                              fold=1:k))

quality.avg <<- array(0, dim=c(1,4,5),
                    dimnames=list(dataset=datanames,
                                  measure=c("acc", "pre", "sen", "spe"),
                                  method=c("NB", "CART","J48", "RadSVM","SIA")))


#seed = 20190101
seed = 20190201


# tabclass1=unique(dataset$class)
# print("tabclass1[0]")
# print("tabclass1[1]")
# print(as.character(tabclass1))
# print(as.character(tabclass1[1]))

#repeat {
for(D in 1:1) { # for each dataset
  dataset = datasets[[D]]
  
 
# for replicability
  set.seed(seed)
  # labels of folds
  gr0 <- cut(x=1:dim(dataset)[1], breaks=k, include.lowest=TRUE, labels=FALSE)
  # gr0 = cut(x=seq(1,dim(dataset[1])), breaks=k, include.lowest=TRUE, labels=FALSE)
  
  # reorder folds randomly
  gr <- sample(gr0)
  # cross validation starts
  for(i in 1:k) { # for each fold
    # divide train and test data
    #ts <- dataset[gr==i,]
    
    tr <- dataset[gr!=i,]
    ts <- dataset[gr==i,]
    
    # apply methods to train data and predict on test data
    NBtr = naiveBayes(formula=class~., data=tr)
    
    predNB = predict(NBtr, newdata=ts, type="class")
    
    u <-union(predNB,ts[, "class"])
    
    CM = confusionMatrix(data=table(factor(predNB,u), factor(ts[, "class"],u)),
                         positive=positive[D])
    quality[dataset=datanames[D],,method="NB",fold=i] = c(CM$overall["Accuracy"],
                                                          CM$byClass[c("Precision", "Sensitivity", "Specificity")])
    
    J48tr = J48(formula=class~., data=tr)
    predJ48 = predict(J48tr, newdata=ts, type="class")
    
    u <-union( predJ48,ts[, "class"])
    
    CM = confusionMatrix(data=table(factor(predJ48,u), factor(ts[, "class"],u)),
                         positive=positive[D])
    quality[dataset=datanames[D],,method="J48",fold=i] = c(CM$overall["Accuracy"],
                                                           CM$byClass[c("Precision", "Sensitivity", "Specificity")])
    CARTtr = rpart(formula=class~., data=tr)
    predCART = predict(CARTtr, newdata=ts, type="class")
    
    u <-union( predCART,ts[, "class"])
    
    CM = confusionMatrix(data=table(factor(predCART,u), factor(ts[, "class"],u)),
                         positive=positive[D])
    quality[dataset=datanames[D],,method="CART",fold=i] = c(CM$overall["Accuracy"],
                                                            CM$byClass[c("Precision", "Sensitivity", "Specificity")])
    RadSVMtr = svm(formula=factor(class) ~ ., data=tr, type="C-classification")
    predRadSVM = predict(RadSVMtr, newdata=ts, type="class")
    
    u <-union( predRadSVM,ts[, "class"])
    
    CM = confusionMatrix(data=table(factor(predRadSVM,u), factor(ts[, "class"],u)),
                         positive=positive[D])
    quality[dataset=datanames[D],,method="RadSVM",fold=i] = c(CM$overall["Accuracy"],
                                                              CM$byClass[c("Precision", "Sensitivity", "Specificity")])
    
    
    SIAtr <<- SIAclassif(formula=class~., data=tr, implif0=0,nvotes=vote,
                         positive=positive[D], optim='accuracy', verbose=TRUE)

    if(ninputvars>0) {  # si le seuil d'implifiance est > aux valeurs d'implifiance donc la classification n'est pas faite donc on peut pas faire la pr?diction 
      
      predSIA = predict(SIAtr, newdata=ts)
     u <-union( predSIA,ts[, "class"])
      
     CM = confusionMatrix(data=table(factor(predSIA,u), factor(ts[, "class"],u)),
                          positive=positive[D])
      quality[dataset=datanames[D],,method="SIA",fold=i] = c(CM$overall["Accuracy"],
                                                            CM$byClass[c("Precision", "Sensitivity", "Specificity")])
       }
  }
  # all results
 
  
  quality.avg[datanames[D],,] <<- apply(X=quality[datanames[D],,,], MAR=c(1,2), FUN='weighted.mean', w=table(gr))
  # and now averaging (taking into account different folds sizes)
}

aperm(quality.avg, perm=c(3,2,1))

print(quality.avg)
#aperm(quality.avg, perm=c(3,2,1))

#print(quality.avg)
#if(sum(is.na(aperm(quality.avg, perm=c(3,2,1)))) == 0) {
#  cat("seed= ", seed)
#  break
#}
#seed = seed + 1
#}
#aperm(quality.avg, perm=c(3,2,1))
# POSIBLEMENTE LOS ERRORES DE NA EN LA MA+TRIZ DE CALIDAD DE ALGUNOS METODOS
# SE DEBEN A QUE LOS TRAIN DATA A VECES NO CUBREN EN ALGUNA VARIABLE
# TODOS LOS NIVELES DEL FACTOR
}