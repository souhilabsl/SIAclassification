#' @title Runs the classification 
#'
#' @description 
#' 
#' @author 
#' @export
#' @docType package
#' @name Classif






Classif <-function() {
  
  require(tcltk) || stop("tcltk support is absent")
  require(stringr) || stop("stringr support is absent")
  require(tcltk2) || stop("tcltk2 support is absent")
  require(Rgraphviz) || stop("Rgraphviz support is absent")
  
  
  #select file
  fileName <- tclvalue(tkgetOpenFile())
  
  if (!nchar(fileName)) {
    tkmessageBox(message = "No file was selected!")
    setwd(initDirectory)
  }else{
    
    vote<<-3
    data1 = read.csv(fileName,sep=",",as.is=T)
    vecClass=data1[,"class"]
    vecClass=unique(vecClass)
    var1=vecClass[1]
    var2=vecClass[2]
    vecVar=names(data1)
    
    
    nbVar=length(vecVar)-1
    base=tktoplevel()
    tkwm.title(base, "classification")
    
    makepresser=function(n){force(n);function(){
      
      vote <<- as.numeric(tclvalue( tkget(zone_variable,
                                          tkcurselection(zone_variable))) )
      
      positif<<-n
      
      tkdestroy(base)
      siaclasifcrossvali(fileName)
    }}
    
    fr2=tkframe(base)
    tkpack(fr2)
    
    t3=tklabel(fr2,text="Enter Nvotes (slide to select) \n")
    tkpack(t3, side="left")
    
    zone_variable = tklistbox(fr2, height=3, exportselection=1)
    k=1
    while(k <= nbVar)
    {
      
      tkinsert(zone_variable,"end",k)	# ajout de math
      
      k=k+2
    }
    
    fr3=tkframe(base)
    tkpack(fr3)
    
    t2=tklabel(fr3,text="positive class")
    tkpack(t2, side="left")
    tkpack(zone_variable)
    
    # creation et affichage du troisieme frame
    
    bs = list()
    
    
    for(i in vecClass)
    { bs[[i]]=tkbutton(fr3, text=i,command=makepresser(i))
    tkpack(bs[[i]]) }
    
  }
}